import os

TZ = os.getenv("TZ", "Asia/Tehran")
GROUP = os.getenv("GROUP", "popular")
SCORE_TH = int(os.getenv("SCORE_TH", "80"))
ETA_MAX_H = int(os.getenv("ETA_MAX_H", "6"))
EXCLUDE_SYMBOLS = os.getenv("EXCLUDE_SYMBOLS", "dupeusdt,worthlessusdt").split(",")
