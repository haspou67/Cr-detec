import time

if __name__ == "__main__":
    print("🚀 Crash Detector runner started...")
    time.sleep(1)
    print("⏳ Running scan cycle ...")
